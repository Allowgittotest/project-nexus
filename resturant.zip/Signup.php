<?php

$signUpName = $_POST['signUpName'];
$signUpUsername = $_POST['signUpUsername'];
$signUpPassword	 = $_POST['signUpPassword'];
$signUpConfirmPassword = $_POST['signUpConfirmPassword'];




if (!empty($signUpName) || !empty($signUpUsername) || !empty($signUpPassword) || !empty($signUpConfirmPassword) )
{

$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "project";



// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);

if (mysqli_connect_error()){
  die('Connect Error ('. mysqli_connect_errno() .') '
    . mysqli_connect_error());
}
else{
  $SELECT = "SELECT signUpUsername From signup Where signUpUsername = ? Limit 1";
  $INSERT = "INSERT Into signup (signUpName , signUpUsername ,signUpPassword, signUpConfirmPassword)values(?,?,?,?)";

//Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $signUpUsername);
     $stmt->execute();
     $stmt->bind_result($signUpUsername);
     $stmt->store_result();
     $rnum = $stmt->num_rows;

     //checking username
      if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ssss", $signUpName,$signUpUsername,$signUpPassword,$signUpConfirmPassword);
      $stmt->execute();
      echo "New record inserted sucessfully";
     } else {
      echo "Someone already register using this email";
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "All field are required";
 die();
}
?>