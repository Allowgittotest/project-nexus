<?php
session_start();

// Include your database configuration file
include("php/config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle Sign In form submission
    $signInUsername = mysqli_real_escape_string($con, $_POST['signInUsername']);
    $signInPassword = mysqli_real_escape_string($con, $_POST['signInPassword']);

    $query = "SELECT * FROM users WHERE Username = '$signInUsername' AND Password = '$signInPassword'";
    $result = mysqli_query($con, $query);

    if ($result) {
        if (mysqli_num_rows($result) == 1) {
            // Authentication successful
            $user = mysqli_fetch_assoc($result);

            // Store user information in session
            $_SESSION['valid'] = true;
            $_SESSION['id'] = $user['Id'];

            // Redirect to the home page or wherever you want
            header("Location: home.php");
            exit();
        } else {
            // Authentication failed
            $error = "Invalid username or password";
        }
    } else {
        // Query failed
        $error = "Error executing query";
    }
}
?>
